import { HttpStatus } from '@nestjs/common';
export declare class AppController {
    constructor();
    healthCheck(): any;
    login(req: any): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {};
    }>;
    getProfile(req: any): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            user: any;
        };
    }>;
}
