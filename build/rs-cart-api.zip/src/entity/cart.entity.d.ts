import { CartItem } from './cartItem.entity';
export declare enum CartStatus {
    OPEN = "OPEN",
    ORDERED = "ORDERED"
}
export declare class Cart {
    id: string;
    user_id: string;
    status: CartStatus;
    items: CartItem[];
    cartItems: CartItem[];
}
