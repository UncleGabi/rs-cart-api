import { Cart } from '../models';
export declare function calculateCartTotal(cart: Cart): number;
