"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const cart_entity_1 = require("../../entity/cart.entity");
const cartItem_entity_1 = require("../../entity/cartItem.entity");
let CartService = class CartService {
    async findByUserId(userId) {
        return await this.cartRepository.findOne({ where: { user_id: userId } });
    }
    async createByUserId(userId) {
        const userCart = await this.cartRepository.create({
            user_id: userId,
            items: [],
        });
        return this.cartRepository.save(userCart);
    }
    async findOrCreateByUserId(userId) {
        const userCart = await this.findByUserId(userId);
        if (userCart) {
            return userCart;
        }
        return this.createByUserId(userId);
    }
    async updateByUserId(userId, { items }) {
        const cart = await this.cartRepository.findOne({
            where: { user_id: userId },
        });
        if (!cart) {
            throw new Error(`Cart not found for user id ${userId}`);
        }
        await this.cartItemRepository.delete({ cart: { id: cart.id } });
        cart.cartItems = items.map((item) => {
            const cartItem = new cartItem_entity_1.CartItem();
            cartItem.product_id = item.product_id;
            cartItem.count = item.count;
            cartItem.cart = cart;
            return cartItem;
        });
        await this.cartRepository.save(cart);
        return cart;
    }
    async removeByUserId(userId) {
        await this.cartRepository.delete({ user_id: userId });
    }
};
exports.CartService = CartService;
__decorate([
    (0, typeorm_1.InjectRepository)(cart_entity_1.Cart),
    __metadata("design:type", typeorm_2.Repository)
], CartService.prototype, "cartRepository", void 0);
__decorate([
    (0, typeorm_1.InjectRepository)(cartItem_entity_1.CartItem),
    __metadata("design:type", typeorm_2.Repository)
], CartService.prototype, "cartItemRepository", void 0);
exports.CartService = CartService = __decorate([
    (0, common_1.Injectable)()
], CartService);
//# sourceMappingURL=cart.service.js.map