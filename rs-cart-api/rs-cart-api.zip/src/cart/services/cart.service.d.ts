import { Cart } from '../../entity/cart.entity';
export declare class CartService {
    private readonly cartRepository;
    private readonly cartItemRepository;
    findByUserId(userId: string): Promise<Cart>;
    createByUserId(userId: string): Promise<Cart>;
    findOrCreateByUserId(userId: string): Promise<Cart>;
    updateByUserId(userId: string, { items }: Cart): Promise<Cart>;
    removeByUserId(userId: string): Promise<void>;
}
