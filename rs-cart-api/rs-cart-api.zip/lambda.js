"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pg_1 = require("pg");
const express = require("express");
const app_module_1 = require("./src/app.module");
const platform_express_1 = require("@nestjs/platform-express");
const core_1 = require("@nestjs/core");
const middleware_1 = require("aws-serverless-express/middleware");
const helmet = require("helmet");
const aws_serverless_express_1 = require("aws-serverless-express");
let cachedServer;
const bootstrap = async () => {
    if (!cachedServer) {
        const expressApp = express();
        const app = await core_1.NestFactory.create(app_module_1.AppModule, new platform_express_1.ExpressAdapter(expressApp), { cors: true, logger: ['error', 'warn', 'log', 'verbose', 'debug'] });
        app.use((0, middleware_1.eventContext)());
        app.use(helmet());
        app.use(helmet.noSniff());
        app.use(helmet.hidePoweredBy());
        app.use(helmet.contentSecurityPolicy());
        await app.init();
        cachedServer = (0, aws_serverless_express_1.createServer)(expressApp, undefined);
    }
    return cachedServer;
};
const initializeDatabase = async (client) => {
    try {
        await client.query(`CREATE TYPE cart_status AS ENUM ('OPEN', 'ORDERED')`);
    }
    catch (err) {
        console.warn('Type cart_status may already exist:', err);
    }
    try {
        await client.query(`
        CREATE TABLE carts (
          id UUID PRIMARY KEY,
          user_id UUID NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE NOT NULL,
          updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
          status cart_status NOT NULL
        )
      `);
    }
    catch (err) {
        console.warn('Table carts may already exist:', err);
    }
    try {
        await client.query(`
        CREATE TABLE cart_items (
          cart_id UUID REFERENCES carts(id),
          product_id UUID,
          count INTEGER
        )
      `);
    }
    catch (err) {
        console.warn('Table cart_items may already exist:', err);
    }
};
const checkTablesExist = async (client) => {
    const checkTablesQuery = `
      SELECT tablename 
      FROM pg_tables 
      WHERE tablename IN ('carts', 'cart_items')
    `;
    const res = await client.query(checkTablesQuery);
    console.log('Tables found:', res.rows.map((row) => row.tablename));
    return res.rows.length === 2;
};
exports.handler = async function (event, context) {
    var _a, _b, _c, _d, _e;
    console.log('Event:', event);
    const DB_USER_NAME = (_a = process.env.DB_USER_NAME) !== null && _a !== void 0 ? _a : '';
    const DB_USER_PASSWORD = (_b = process.env.DB_USER_PASSWORD) !== null && _b !== void 0 ? _b : '';
    const DB_PORT = (_c = process.env.DB_PORT) !== null && _c !== void 0 ? _c : '';
    const DB_HOST = (_d = process.env.DB_HOST) !== null && _d !== void 0 ? _d : '';
    const DB_NAME = (_e = process.env.DB_NAME) !== null && _e !== void 0 ? _e : '';
    try {
        const client = new pg_1.Client({
            host: DB_HOST,
            port: DB_PORT,
            database: DB_NAME,
            user: DB_USER_NAME,
            password: DB_USER_PASSWORD,
        });
        await client.connect();
        await initializeDatabase(client);
        checkTablesExist(client);
        client.query('SELECT * FROM carts', (err, res) => {
            console.log(err, res);
        });
        console.log('connected to pg client: ');
        try {
            const res = await client.query('SELECT NOW()');
            console.log('Current time: ', res.rows[0].now);
        }
        catch (err) {
            console.error('Error running query:', err);
        }
        await client.end();
        console.log('postgres test successfull');
        cachedServer = await bootstrap();
        return (0, aws_serverless_express_1.proxy)(cachedServer, event, context, 'PROMISE').promise;
    }
    catch (err) {
        console.error('Error retrieving secret:', err);
    }
};
//# sourceMappingURL=lambda.js.map